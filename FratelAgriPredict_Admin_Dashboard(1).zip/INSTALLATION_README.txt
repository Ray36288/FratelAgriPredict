FRATEL-AGRIPREDICT — ADMINISTRATOR DASHBOARD PACKAGE

FILES
1. admin-dashboard.html
2. admin-dashboard.css
3. admin-dashboard.js
4. APP_JS_ADMIN_ROUTING_PATCH.txt

WHAT THE DASHBOARD INCLUDES
- Administrator-only access check using profiles.role + secured user_roles table.
- Overview: registered/active farmers, active projects, pending exit requests, farms, enterprises and batch summary.
- Farmer accounts: search/filter, edit basic profile details, activate/suspend accounts, promote/demote administrator roles using protected Supabase RPCs.
- Projects: create/edit projects, activate/deactivate them and maintain milestone lists.
- Enrolments: view active and historical enrolments and create an enrolment for an active farmer/project.
- Exit requests: approve/decline through admin_review_unenrollment, with an administrator response.
- Project progress: review status, completion percentage and administrator notes.
- Farm operations: read-only farm, enterprise, livestock batch and financial ledger summaries.
- Audit trail: read-only administrator change log.

INSTALLATION IN GITHUB (UPLOAD THESE 3 FILES TO THE REPOSITORY ROOT)
1. Download and extract this ZIP on your computer.
2. Open https://github.com/Ray36288/FratelAgriPredict
3. Select the main branch.
4. Choose Add file > Upload files.
5. Drag admin-dashboard.html, admin-dashboard.css and admin-dashboard.js into the upload area. Make sure they are at the repository root, beside dashboard.html and app.js, not inside a new folder.
6. Commit the three new files to the main branch.

ENABLE ADMIN LOGIN ROUTING
1. Open app.js in the same repository and click Edit (pencil icon).
2. Follow the exact replacement instructions in APP_JS_ADMIN_ROUTING_PATCH.txt.
3. Commit the app.js change to main.
4. Wait for GitHub Pages to publish, then sign out and sign in again.
5. The admin account should open admin-dashboard.html; farmer accounts should continue to open dashboard.html.

IMPORTANT DATABASE EXPECTATIONS
This dashboard is written for the AgriPredict central database migration named agripredict_database_v1.sql, including the tables:
user_roles, farms, farm_enterprises, project_milestones, farmer_project_progress,
project_unenrollment_requests, inventory_items, livestock_batches,
farm_transactions, admin_audit_logs, plus the existing profiles, projects,
and project_enrollments tables.

It calls these protected Supabase functions:
admin_set_user_role(p_user_id, p_role)
admin_set_farmer_status(p_user_id, p_status)
admin_review_unenrollment(p_request_id, p_decision, p_admin_response)

The admin role must exist in public.user_roles and profiles.role must be 'admin'.
The admin profile must have account_status = 'active'. Your previously configured
administrator account should already satisfy those requirements.

SECURITY AND LIMITATIONS
- The dashboard uses the existing Supabase publishable key from supabase-config.js.
- Never add a Supabase service-role/secret key to browser code.
- The UI uses existing RLS policies and protected admin RPCs; the UI itself is not
  the security boundary.
- Profile email is displayed but not editable here because changing a Supabase
  Auth login email requires an Auth operation, not an update to profiles.email.
- Farmer accounts are suspended, not deleted. Project records and enrolment history
  are retained. Projects are deactivated rather than deleted.
- Farm operations figures show only values actually stored in the database.
  Opening batch quantities are not described as current live animal counts.

TESTING
- Confirm a farmer login still opens dashboard.html.
- Confirm an administrator login opens admin-dashboard.html.
- Confirm the dashboard shows a secure database session and farmer/project rows.
- Test project create/edit and account status actions with a non-critical test row
  before using administrator controls on important records.
